<div class="container">
<h1><?= lang('App.saludo_perfil',[ucfirst(session()->get('nombre'))]) ?></h1>
</div>