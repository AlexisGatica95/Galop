<div class="container">
	<h1 class="titulo-principal">
	Institucional</h1>
	<div class="content">
		<div class="about-left">
			<h3 class="subtitulo-principal">Miembros</h3>
			<div class="miembros-container">
				<button class="slick-prev">
				</button>
					<div class="miembros-content">
						<div class="div-miembros">
							<div class="user-img">
							</div>
							<h3 class="miembros-titulo">Nombre1</h3>
							<h4 class="miembros-cargo">Cargo</h4>
							<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Minus esse qui voluptatem eos reiciendis nesciunt assumenda minima ducimus, doloribus aliquid soluta commodi, quam accusantium officia expedita doloremque. Laborum, eius similique!</p>
							<div class="redes">
								<img src="/img/fb-icon.png" alt="">
								<img src="/img/tw-icon.png" alt="">
								<img src="/img/in-icon.png" alt="">
							</div>
						</div>
					</div>
					<div class="miembros-content">
						<div class="div-miembros">
							<div class="user-img">
							</div>
							<h3 class="miembros-titulo">Nombre2</h3>
							<h4 class="miembros-cargo">Cargo</h4>
							<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Minus esse qui voluptatem eos reiciendis nesciunt assumenda minima ducimus, doloribus aliquid soluta commodi, quam accusantium officia expedita doloremque. Laborum, eius similique!</p>
							<div class="redes">
								<img src="/img/fb-icon.png" alt="">
								<img src="/img/tw-icon.png" alt="">
								<img src="/img/in-icon.png" alt="">
							</div>
						</div>
					</div>
					<div class="miembros-content">
						<div class="div-miembros">
							<div class="user-img">
							</div>
							<h3 class="miembros-titulo">Nombre3</h3>
							<h4 class="miembros-cargo">Cargo</h4>
							<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Minus esse qui voluptatem eos reiciendis nesciunt assumenda minima ducimus, doloribus aliquid soluta commodi, quam accusantium officia expedita doloremque. Laborum, eius similique!</p>
							<div class="redes">
								<img src="/img/fb-icon.png" alt="">
								<img src="/img/tw-icon.png" alt="">
								<img src="/img/in-icon.png" alt="">
							</div>
						</div>
					</div>
					<div class="miembros-content">
						<div class="div-miembros">
							<div class="user-img">
							</div>
							<h3 class="miembros-titulo">Nombre4</h3>
							<h4 class="miembros-cargo">Cargo</h4>
							<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Minus esse qui voluptatem eos reiciendis nesciunt assumenda minima ducimus, doloribus aliquid soluta commodi, quam accusantium officia expedita doloremque. Laborum, eius similique!</p>
							<div class="redes">
								<img src="/img/fb-icon.png" alt="">
								<img src="/img/tw-icon.png" alt="">
								<img src="/img/in-icon.png" alt="">
							</div>
						</div>
					</div>
					<div class="miembros-content">
						<div class="div-miembros">
							<div class="user-img">
							</div>
							<h3 class="miembros-titulo">Nombre5</h3>
							<h4 class="miembros-cargo">Cargo</h4>
							<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Minus esse qui voluptatem eos reiciendis nesciunt assumenda minima ducimus, doloribus aliquid soluta commodi, quam accusantium officia expedita doloremque. Laborum, eius similique!</p>
							<div class="redes">
								<img src="/img/fb-icon.png" alt="">
								<img src="/img/tw-icon.png" alt="">
								<img src="/img/in-icon.png" alt="">
							</div>
						</div>
					</div>
				<button class="slick-next">
				</button>						
			</div>
			
		</div>
		<ul class="buttons-right">
		<li>
			<a class="" href="/institucional/quienes-somos">Quienes Somos</a>
		</li>
		<li>
			<a class="" href="/institucional/estatuto">Estatuto</a>
		</li>
		<li>
			<a  class="active" href="/institucional/miembros">Miembros</a>
		</li>
		<li>
			<a class="" href="/institucional/comites">Comites</a>
		</li>
		</div>
		
	</div>	
	
</div>