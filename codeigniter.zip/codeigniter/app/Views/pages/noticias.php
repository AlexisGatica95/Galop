<div class="container">
<h1 class="titulo-principal">Noticias</h1>    
</div>
