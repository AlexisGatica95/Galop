<div class="container">
<h1 class="titulo-principal">Contacto</h1>
    <div class="form-container">
        <div class="contacto-left">
            <h3>Envianos tu comentario</h3>
            <hr>
            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Enim ad debitis nisi deserunt impedit. Sunt minima doloribus eum quidem dolorum sint, in aperiam tempora, aliquid earum suscipit. Non, minus recusandae.</p>
            <span class="mail"></span>
            <span class="tel"></span>
            <hr>
            <h3>follow us</h3>
            <hr>
            <div class="redes">
                <img src="/img/fb-icon.png" alt="">
                <img src="/img/tw-icon.png" alt="">
                <img src="/img/in-icon.png" alt="">
            </div>
        </div>

        <div class="contacto-right">
            <form action="" class="form-contacto">
            <label for="">
                <span>Nombre</span>
                <input type="text" class="form-input">
            </label>
            <label for="">
                <span>E-mail</span>
                <input type="text" class="form-input">
            </label>
            <label for="">
                <span>Sujeto</span>
                <input type="text" class="form-input">
            </label>
            <label for="">
                <span>Mensaje</span>
                <textarea cols="30" rows="10" class="form-input">
                </textarea>
            </label>
            <input type="submit" value="Enviar" class="form-button">
            </form>
        </div>
        
    </div>
    
</div>
