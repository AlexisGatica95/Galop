<div class="container">
	<h1 class="titulo-principal">
	Institucional</h1>
	<div class="content">
		<div class="about-left">
			<h3 class="subtitulo-principal">Quienes Somos</h3>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Necessitatibus excepturi adipisci in itaque commodi nesciunt ipsum harum mollitia corporis, nam illum dolor nulla atque rerum sit aut quod, minima deserunt!
			Lorem ipsum dolor sit amet, consectetur adipisicing elit. Necessitatibus excepturi adipisci in itaque commodi nesciunt ipsum harum mollitia corporis, nam illum dolor nulla atque rerum sit aut quod, minima deserunt!
			</p>	
		</div>
		<ul class="buttons-right">
		<li>
			<a  class="active" href="/institucional/quienes-somos">Quienes Somos</a>
		</li>
		<li>
			<a  class="" href="/institucional/estatuto">Estatuto</a>
		</li>
		<li>
			<a  class="" href="/institucional/miembros">Miembros</a>
		</li>
		<li>
			<a  class="" href="/institucional/comites">Comites</a>
		</li>
		</div>
		
	</div>	
	
</div>