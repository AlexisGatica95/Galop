<div class="container">
	<h1 class="titulo-principal">
	Institucional</h1>
	<div class="content">
		<div class="about-left">
			<h3 class="subtitulo-principal">El grupo</h3>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Necessitatibus excepturi adipisci in itaque commodi nesciunt ipsum harum mollitia corporis, nam illum dolor nulla atque rerum sit aut quod, minima deserunt!
			Lorem ipsum dolor sit amet, consectetur adipisicing elit. Necessitatibus excepturi adipisci in itaque commodi nesciunt ipsum harum mollitia corporis, nam illum dolor nulla atque rerum sit aut quod, minima deserunt!
			</p>	
		</div>
		<ul class="buttons-right">
			<li class="active">
				<a href="">Quienes Somos</a>
			</li>
			<li class="">
				<a href="/institucional/estatuto">Estatuto</a>
			</li>
			<li class="">
				<a href="/institucional/miembros">Miembros</a>
			</li>
			<li class="">
				<a href="/institucional/comites">Comites</a>
			</li>
		</div>
		
	</div>	
	
</div>