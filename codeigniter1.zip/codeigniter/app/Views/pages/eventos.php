<div class="container">
    <h1 class="titulo-principal"><?= ucfirst(lang("Admin.menu_eventos"))?></h1>    
</div>
