$(document).ready(function(){

	new SlimSelect({
        select: "#filtro_permisos",
        showSearch: false,
    	});

});