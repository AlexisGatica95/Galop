$(document).ready(function(){

	new SlimSelect({
        select: "#filtro_estado",
        showSearch: false,
    });
    
    new SlimSelect({
    	select: "#filtro_lenguaje",
    	showSearch: false
    });

    new SlimSelect({
    	select: "#filtro_categoria",
    	showSearch: false
    });


});